## [Get Started](Getting-Started.md)

Setting up jsprit and the like.

## Examples

* [Simple Example](Simple-Example.md)
* [More Examples](More-Examples.md)
* [A number of various code examples](https://github.com/graphhopper/jsprit/tree/master/jsprit-examples/src/main/java/com/graphhopper/jsprit/examples)

## [Meta-Heuristic](Meta-Heuristic.md)

Gives a basic description of the applied meta-heuristic.



