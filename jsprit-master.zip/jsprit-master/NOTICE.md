jsprit is licensed under the Apache license, Version 2.0

Copyright 2012 - 2021 GraphHopper GmbH

The jsprit-core module includes the following software:

 * commons.apache.org/proper/commons-math/ - Commons Math is distributed under the terms of the Apache License, Version 2.0
 * slf4j.org - SLF4J distributed under the MIT license.

jsprit-analysis:

 * graphstream/gs-core, gs-ui - licensed under LGPL 3.0
 * jfree.org - jfreechart licensed under LGPL 2.1

jsprit-io:

 * commons-configuration - Apache License 2.0
 * xerces - Apache License 2.0

jsprit-instances:

 * no dependency

jsprit-examples:

 * log4j - Apache License 2.0

jsprit:

 * mockito - MIT License
 * junit - Eclipse Public License - v 1.0
